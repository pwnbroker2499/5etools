"use strict";

// TODO factor shared save processing to a common adapter here
//   See: DM Screen
//   See e.g.: https://github.com/5etools-mirror-1/5etools-mirror-1.github.io/pull/39
