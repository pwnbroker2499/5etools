Please fill out as much of this template as possible/is applicable.

Is this a bug or a feature request:

Issue:

Page(s) affected:

Reproduction steps:

Additional information:

Browser (Chromium, Firefox, Edge, etc):

Platform (Windows, iOS, Android, etc):
